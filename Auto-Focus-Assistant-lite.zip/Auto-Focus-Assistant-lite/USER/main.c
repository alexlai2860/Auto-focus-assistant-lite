#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"
#include "uart3.h"
#include "motor.h"
#include "Serial.h"

/************************************************
��Ƭ���γ����
2023/7/8
���ߣ�Lai,Huang,Li
************************************************/


 int main(void)
 {	
	// motor
	int min_dis;
	int last_dis;
	int last_lidar_dis[10];
	int x;
	u8 focus_dis;
	uint8_t flag = 0;
	uint8_t clear_flag = 0;
	uint8_t string[17];
	uint8_t *__send_string;
	u16 pos;
	uint8_t nucleus_cal[17] = {':', '3', 'F', '0', '6', '0', '0', '0', '1', '0', '0', '0', '1', 'B', '9', 0x0D, 0X0A};
	uint8_t init_mode = 2;
	uint8_t operate_mode = 1;		// 1:MF 0:AF
	uint8_t mode;
	 
	// screen
	int i = 0;
	u8 count1 = 0;
  u8 count2 = 0;
	u8 key = 0;
	u8 lcd_id[12];			                                    //���LCD ID�ַ���
	//int data_x[10] = {-40,-30,-20,-10,0,10,20,30,35,40};    //��Ž��յ��״�����
	//int data_y[10] = {1,2,3,4,5,6,7,8,9,9}; 
	int data_y[40] = {0};    //��Ž��յ��״�����
	int data_x[40] = {-40,-38,-36,-34,-32,-30,-28,-26,-24,-22,-20,-18,-16,-14,-12,-10,-8,-6,-4,-2,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38};
	int *px = &data_x[0];
	int *py = &data_y[0];
	
	mode = init_mode;
	 
	delay_init();	    	                                    //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	        //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	                                    //���ڳ�ʼ��Ϊ115200
	uart3_init(115200);
	Serial_Init();
 	LED_Init();			                                        //LED�˿ڳ�ʼ��
	LCD_Init();
	KEY_Init();         	                                  //��ʼ���밴�����ӵ�Ӳ���ӿ�
	LED1=0;					                                        //�ȵ����̵�

	sprintf((char*)lcd_id,"LCD ID:%04X",lcddev.id);         //��LCD ID��ӡ��lcd_id����
	LCD_Clear(WHITE);                                       //����
	
  //LCD��ʼ�������
	POINT_COLOR=RED;      //���ʳ�ʼ��Ϊ��ɫ
	LCD_ShowString(20,10,200,16,16,"On/Off"); 
  //LCD_ShowString(140,10,200,16,16,"Manual/Auto");	 

	POINT_COLOR=BROWN;    //���ʳ�ʼ��Ϊ��ɫ
	LCD_ShowString(210,35,200,12,12,"10m"); 
	LCD_ShowString(210,120,200,12,12,"5m"); 
	LCD_ShowString(210,215,200,12,12,"0m"); 
	
	POINT_COLOR=BRED;     //���ʳ�ʼ��Ϊ��ɫ
	LCD_ShowString(5,240,200,12,12,"-40��"); 
	LCD_ShowString(100,240,200,12,12,"0��"); 
	LCD_ShowString(185,240,200,12,12,"40��"); 
	
	POINT_COLOR=BLACK;    //���ʳ�ʼ��Ϊ��ɫ
	LCD_ShowString(60,260,200,24,24,"Waveform");
	LCD_DrawLine(0,30,239,30);
	LCD_DrawLine(0,230,239,230);
	LCD_DrawLine(200,30,200,230);
	
	POINT_COLOR=BLUE;     //���ʳ�ʼ��Ϊ��ɫ
  LCD_ShowString(5,300,200,12,12,"By Alex,Huang and Li"); 	 	
	
	
	// mode == 2: Calibrate Mode
	USART_SendString(USART3, nucleus_cal);
	delay_ms(2000);
	
	while(1)
	{ 	 
	  key=KEY_Scan(0);
		for(x =0;x<40;x++)
		{
			data_y[x] = RADAR[2*x]/100;
		}
	 	if(key)
		{						   
			if(key ==  KEY0_PRES)
      {
			  count1 ++;
				switch(count1%2)
			{				 
				case 0:	
					LCD_Fill(0,31,199,229,WHITE);                      //����ͼ��������
					POINT_COLOR=RED; 
				  LCD_ShowString(20,10,200,16,16,"On/Off");  
					break; 
				case 1:	
					POINT_COLOR=GREEN; 
				  LCD_ShowString(20,10,200,16,16,"On/Off"); 
					for(i = 0;i < 9;i++)
					{
						LCD_DrawWave(*(px+i),*(py+i),*(px+i+1),*(py+i+1));
					}
					
					break;
        default:
					LED0 = 0;
				  LED1 = 1; //����ƾ���
			}
			
		  }
			if(key ==  KEY1_PRES)
      {
			  count2 ++;
				switch(count2%2)
			{				 
				case 0:	
					POINT_COLOR=RED; 
					mode = 1;
				  LCD_ShowString(140,10,200,16,16,"Manual"); 
					break; 
				case 1:	
					POINT_COLOR=GREEN; 
					mode = 0;
				  LCD_ShowString(140,10,200,16,16,"Auto");
					break;
        default:
					LED0 = 0;
				  LED1 = 1; //����ƾ���
			}
			}
			if(key ==  WKUP_PRES)
			{
			   LCD_Fill(0,31,199,229,WHITE);
			}
		}
		
		//mode = 1;
		if(mode == 0)
		{
			// mode == 0: Auto Focus Mode
			uint16_t dis;
			min_dis = Lidar_min(15);
			// USART_SendData(USART1,min_dis);
			if(min_dis!=0)
			{
				flag = 1;
			}
			if(flag == 1){
			if(min_dis>9999)
			{
				min_dis = 9999;
			}
			else if(min_dis<500)
			{
				min_dis = 500;
			}
			pos = lagrange(min_dis,7,0); // test
			__send_string = pose2data(pos,string);
			USART_SendString(USART3, string);
			USART_SendString(USART1, string);
			
			POINT_COLOR=RED;
			LCD_DrawWave(-40,min_dis, 39, min_dis);
			for(i = 0;i < 39;i++)
			{
				POINT_COLOR=BLUE;
				LCD_DrawWave(*(px+i),*(py+i),*(px+i+1),*(py+i+1));
			}
			LCD_Fill(0,31,199,229,WHITE);
			// delay_ms(10);
			}
		}
		else if(mode == 1)
		{
			int pos;
			int lidar_dis;
			int y;
			// mode == 1: Manual Focus Mode
						
			// USART_SendData(USART1,lidar_dis);
			USART_SendString(USART3, manual_data);
			focus_dis = manual_dis/100;
			USART_SendData(USART1, focus_dis);
			
			POINT_COLOR=GREEN;
			LCD_DrawWave(-40,focus_dis, 39, focus_dis);
			for(i = 0;i < 39;i++)
			{
				POINT_COLOR=BLUE;
				LCD_DrawWave(*(px+i),*(py+i),*(px+i+1),*(py+i+1));
			}
			LCD_Fill(0,31,199,229,WHITE);
			
			// delay_ms(10);
			// USART_SendString(USART1, manual_data);
			// USART_SendString(USART1, manual_data);
			
		}
		else if(mode == 2)
		{
			int lidar_dis;
			int y;
			// USART_SendData(USART1, RADAR[0]);
			clear_flag=0;
			
			USART_SendData(USART1,lidar_dis);
			
			if(clear_flag==1)
			{
			LCD_Fill(0,31,199,229,WHITE);
			}
			else
			{
					for(i = 0;i < 39;i++)
					{
						POINT_COLOR=BLUE;
						LCD_DrawWave(*(px+i),*(py+i),*(px+i+1),*(py+i+1));
					}
					LCD_Fill(0,31,199,229,WHITE);
			}
			delay_ms(10);
		}
			
	}
	//Show_picture(0,0,320,240,(u16*)gImage_jin);
 /* 	while(1) 
	{		 

				switch(x)
		{
			case 0:LCD_Clear(WHITE);break;
			case 1:LCD_Clear(BLACK);break;
			case 2:LCD_Clear(BLUE);break;
			case 3:LCD_Clear(RED);break;
			case 4:LCD_Clear(MAGENTA);break;
			case 5:LCD_Clear(GREEN);break;
			case 6:LCD_Clear(CYAN);break; 
			case 7:LCD_Clear(YELLOW);break;
			case 8:LCD_Clear(BRRED);break;
			case 9:LCD_Clear(GRAY);break;
			case 10:LCD_Clear(LGRAY);break;
			case 11:LCD_Clear(BROWN);break;
		}
	
		POINT_COLOR=RED;	  
		LCD_ShowString(30,40,210,24,24,"Elite STM32F1 ^_^"); 
		LCD_ShowString(30,70,200,16,16,"TFTLCD TEST");
		LCD_ShowString(30,90,200,16,16,"ATOM@ALIENTEK");
 		LCD_ShowString(30,110,200,16,16,lcd_id);		//��ʾLCD ID	      					 
		LCD_ShowString(30,130,200,12,12,"2015/1/14");	      					 
	    x++;
		if(x==12)x=0;
		LED0=!LED0;				   		 
		delay_ms(1000);	
	} 
*/	
}
 

