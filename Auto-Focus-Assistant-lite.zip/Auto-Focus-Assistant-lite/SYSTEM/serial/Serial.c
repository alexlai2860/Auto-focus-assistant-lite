#include "stm32f10x.h" // Device header
#include <stdio.h>
#include <stdarg.h>
// #include <OLED.h>
#include "Delay.h"
#include "math.h"
#include "Serial.h"
#include "uart3.h"


 uint8_t Serial_TxPacket[4];				//FF 01 02 03 04 FE
 uint8_t Serial_RxPacket[47];
 uint16_t RADAR[81];//RADAR[81][47]
 uint8_t Serial_RxFlag;
 uint8_t Lidar_state =1;


uint16_t  Lidarpoints[81*12];




void Serial_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = 230400;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode =  USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2, &USART_InitStructure);
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART2, ENABLE);
}

void USART1_Init(void)
{	
GPIO_InitTypeDef GPIO_InitStructure;
 USART_InitTypeDef USART_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode =  USART_Mode_Tx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//	
//	NVIC_InitTypeDef NVIC_InitStructure;
//	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//	NVIC_Init(&NVIC_InitStructure);
		USART_Cmd(USART1, ENABLE);
	}









uint8_t Serial_GetRxFlag(void)
{
	if (Serial_RxFlag == 1)
	{
		Serial_RxFlag = 0;
		return 1;
	}
	return 0;
}

uint16_t  transfer_datatype(uint8_t a, uint8_t b)
{
	return(((uint16_t)a<<8)+(uint16_t )b);
}

void Analyst_data(void)
{
	static int   startangle;
	startangle=transfer_datatype(Serial_RxPacket[5],Serial_RxPacket[4])/100;
	if(startangle>=0 && startangle <=40)
	{	
		RADAR[startangle+40]=transfer_datatype(Serial_RxPacket[7],Serial_RxPacket[6])*cos(startangle*3.14/180);
	}
	else if(startangle>=320 && startangle <=360)
	{
			RADAR[startangle-320]=transfer_datatype(Serial_RxPacket[7],Serial_RxPacket[6])*cos(startangle*3.14/180);
	}
	// USART_SendData(USART1, RADAR[0]);
}
//	switch(pRxPacket)
//		{
//		case 0:break;
//		case 1:break;
//		case 2:RADAR [startangle].speed =transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);break;
//		case 4:RADAR[startangle].start_angle  =transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);break;
//		case 6:RADAR[startangle].point[0].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [0].intensity =Serial_RxPacket[8];break;
//		case 9:RADAR[startangle].point[1].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [1].intensity =Serial_RxPacket[11];break;
//		case 12:RADAR[startangle].point[2].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [2].intensity =Serial_RxPacket[14];break;
//		case 15:RADAR[startangle].point[3].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [3].intensity =Serial_RxPacket[17];break;	
//		case 18:RADAR[startangle].point[4].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [4].intensity =Serial_RxPacket[20];break;
//		case 21:RADAR[startangle].point[5].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [5].intensity =Serial_RxPacket[23];break;
//		case 24:RADAR[startangle].point[6].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [6].intensity =Serial_RxPacket[26];break;
//		case 27:RADAR[startangle].point[7].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [7].intensity =Serial_RxPacket[29];	break;
//		case 30:RADAR[startangle].point[8].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [8].intensity =Serial_RxPacket[32];	break;
//		case 33:RADAR[startangle].point[9].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [9].intensity =Serial_RxPacket[35];	break;
//		case 36:RADAR[startangle].point[10].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [10].intensity =Serial_RxPacket[38];	break;
//		case 39:RADAR[startangle].point[11].distance = transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);
//			   RADAR[startangle].point [11].intensity =Serial_RxPacket[41];	break;
//		case 42:RADAR[startangle].end_angle =transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);break;	   
//        case 44:RADAR[startangle].timestamp =transfer_datatype(Serial_RxPacket[pRxPacket+1],Serial_RxPacket[pRxPacket]);break;
//		case 46:RADAR[startangle].crc8 =Serial_RxPacket[46];break;
//		default :break;
//	}
	
	
int Lidar_min(int angle)
{
	static int i;
		static uint16_t temp;
	i=40-angle;
	temp=0xFFFF;
while(i<38+angle)
{
	if(temp>RADAR[i])
	{
	temp = RADAR[i];
	}
	i++;
}
	return((int)temp);
    }


void USART2_IRQHandler(void)
{
	static uint8_t RxState = 0;
	static uint8_t pRxPacket = 0;
	if (USART_GetITStatus(USART2, USART_IT_RXNE) == SET  )
	{
		uint16_t RxData = USART_ReceiveData(USART2);
//		USART_SendData(USART1 ,RxData );
//		while(USART_GetFlagStatus (USART1,USART_FLAG_TC )!=SET )
		if (RxState == 0)
		{
			if (RxData == 0x54)
			{
				RxState = 1;
				pRxPacket = 1;
			}
		}
		else if (RxState == 1)
		{
			Serial_RxPacket[pRxPacket] = RxData;
			pRxPacket ++;		
			if (pRxPacket > 45)
			{
				RxState = 2;
			}
		}
		 else if (RxState == 2)
		{
//			USART_SendData(USART1,(uint16_t)Lidar_min(1));
//	    while(USART_GetFlagStatus (USART1 ,USART_FLAG_TC)!=SET );
			Analyst_data ();			
//			OLED_ShowHexNum (2,1,(uint32_t)RADAR [40],4);
			pRxPacket =0;
			RxState = 0;
			Serial_RxFlag = 1;
//			Delay_us (400);
		}
		
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}
}



//void Lidar_update(void)
//{
//      static int i,j;
//	  i=j=0;
//	  
//	  while(i <=80)
//	  {
//		  while(j<12)
//		  {
//			  Lidarpoints[i*12+j]=(int)(transfer_datatype(RADAR[47*i+7+j*3],RADAR[47*i+6+j*3])*cos((40-i-j/12)*3.14159/180));
//			  j++;
//		  }
//		  i++;
//		  j=0;
//	  }
//	
//  }

