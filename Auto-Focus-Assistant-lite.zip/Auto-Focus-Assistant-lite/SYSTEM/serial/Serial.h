#ifndef __SERIAL_H
#define __SERIAL_H

#define POINT_PER_PACK 12
#define HEADER 0x54


#include <stdio.h>

extern uint16_t RADAR[81];
extern uint8_t Serial_TxPacket[4];
extern uint8_t Serial_RxPacket[47];
extern uint8_t Serial_RxFlag;
extern uint16_t Lidarpoints[81*12];


void Serial_Init(void);
void Analyst_data(void);
uint16_t  transfer_datatype(uint8_t a, uint8_t b);
uint8_t Serial_GetRxFlag(void);
void Lidar_update(void);
int Lidar_min(int angle);
void USART1_Init(void);




#endif
