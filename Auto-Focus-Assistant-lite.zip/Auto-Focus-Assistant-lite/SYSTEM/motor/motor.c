//ͷ�ļ�����
#include "stm32f10x.h"
#include "sys.h"
#include "motor.h"

/**
 * @brief ASCII2hex
 *
 * @param data {'F','7'}
 * @return uint8_t 0xF7
 */
uint8_t Ascii2Hex(const uint8_t data_h, const uint8_t data_l)
{
    uint8_t output;
    uint8_t output_h;
    uint8_t output_l;
    // cout << "h" << (int)data_h << endl;
    // cout << "l" << (int)data_l << endl;

    if ((int)data_h >= 65)
    {
        output_h = (int)data_h - 65 + 10;
    }
    else
    {
        output_h = (int)data_h - 48;
    }

    if ((int)data_l >= 65)
    {
        output_l = (int)data_l - 65 + 10;
    }
    else
    {
        output_l = (int)data_l - 48;
    }

    // cout << "oph" << (int)output_h << endl;
    // cout << "opl" << (int)output_l << endl;
    output = output_h << 4 | output_l;
    return output;
}

/**
 * @brief
 *
 * @param data
 * @return uint8_t*
 */
uint8_t* Hex2Ascii(const uint8_t data)
{
	static uint8_t output[2];
    uint8_t output_h;
    uint8_t output_l;
    uint8_t data_h = data >> 4;
    uint8_t data_l = data - (data_h << 4);

    // cout << "data_h" << (int)data_h << endl;
    // cout << "data_h" << (int)data_l << endl;
    if ((int)data_h > 9)
    {
        output_h = (int)data_h - 10 + 65;
    }
    else
    {
        output_h = (int)data_h + 48;
    }

    if ((int)data_l > 9)
    {
        output_l = (int)data_l - 10 + 65;
    }
    else
    {
        output_l = (int)data_l + 48;
    }
    // cout << "oph" << (int)output_h << endl;
    // cout << "opl" << (int)output_l << endl;

    output[0] = output_h;
    output[1] = output_l;
    // return output;
}


/**
 * @brief �������ղ�ֵ(dis2pose)
 *
 * @param dis
 * @param n=7
 * @return float=0
 */
float lagrange(float dis, int n, int flag)
{
    float yResult = 0.0;
	int i;
    const int N = 10;
    float LValue[N];
    int k, m;
    float temp1, temp2;
    if (dis > 500)
    {
        float arrX[8] = {
            500.f,
            1500.f,
            2500.f,
            4000.f,
            6000.f,
            8000.f,
            25000.f};
        float arrY[8] = {
            5582.f,
            3665.f,
            3045.f,
            2535.f,
            2500.f,
            2141.f,
            1816.f};

        if (flag != 0)
        {
            float temp[7];
						int j;
            for (j=0; j < 7; j++)
            {
                temp[j] = arrX[j];
                arrX[j] = arrY[j];
                arrY[j] = temp[j];
            }
        }

        for (k = 0; k < n; k++)
        {
            temp1 = 1.0;
            temp2 = 1.0;
            for (m = 0; m < n; m++)
            {
                if (m == k)
                {
                    continue;
                }
                temp1 *= (dis - arrX[m]);
                temp2 *= (arrX[k] - arrX[m]);
            }

            LValue[k] = temp1 / temp2;
        }
				
        for (i = 0; i < n; i++)
        {
            yResult += arrY[i] * LValue[i];
        }
    }
    else
    {
        return 5582.f;
    }

    return yResult;
}

/**
 * @brief position2data
 *
 * @param pos(0-9999)
 */
uint8_t* pose2data(int position, uint8_t* string)
{
	uint8_t Command;
	uint8_t paramH;
	uint8_t paramL;
	uint8_t dataH;
	uint8_t dataL;
	uint8_t checksum;
	
	SendData5 __send_data5={':','0','1','0','6','0','6','0','0','2','2','0','E','B','E',0x0D, 0x0A};  // 15+2
	if(position >0)
	{
		u16 hex_pos = position;
		uint8_t pos_h = (uint8_t)(hex_pos >> 8);
		uint8_t pos_l = (uint8_t)(hex_pos & 0x00FF);
		// drive NucleusN
    // turn data to ASCII
		uint8_t* data_l;
		uint8_t* data_h;
    uint8_t* checksum_vec; 
    data_h = Hex2Ascii(pos_h);
    __send_data5.data_h[0] = data_h[0];
    __send_data5.data_h[1] = data_h[1];
    data_l = Hex2Ascii(pos_l);
    __send_data5.data_l[0] = data_l[0];
    __send_data5.data_l[1] = data_l[1];

    // calculate checksum
    Command = Ascii2Hex(__send_data5.command[0], __send_data5.command[1]);
    paramH = Ascii2Hex(__send_data5.param_h[0], __send_data5.param_h[1]);
    paramL = Ascii2Hex(__send_data5.param_l[0], __send_data5.param_l[1]);
    dataH = Ascii2Hex(__send_data5.data_h[0], __send_data5.data_h[1]);
    dataL = Ascii2Hex(__send_data5.data_l[0], __send_data5.data_l[1]);
    checksum = (char)(256 - 1 - (Command + paramH + paramL + dataH + dataL));

    // convert checksum
		checksum_vec = Hex2Ascii(checksum);
    __send_data5.checksum[0] = checksum_vec[0];
    __send_data5.checksum[1] = checksum_vec[1];
		
		// format convert
		string[0]=':';
		string[1]='0';
		string[2]='1';
		string[3]='0';
		string[4]='6';
		string[5]='0';
		string[6]='6';
		string[7]='0';
		string[8]='0';
		
		string[9]=__send_data5.data_h[0];
		string[10]=__send_data5.data_h[1];
		string[11]=__send_data5.data_l[0];
		string[12]=__send_data5.data_l[1];
		string[13] = __send_data5.checksum[0];
		string[14] = __send_data5.checksum[1];
		
		string[15]=0x0D;
		string[16]=0x0A;
		
		return string;
	}
	else
	{
		string[0] = '\0';
		return string;
	}
}