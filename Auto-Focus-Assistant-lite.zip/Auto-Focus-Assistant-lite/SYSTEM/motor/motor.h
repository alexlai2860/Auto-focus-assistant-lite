#ifndef __MOTOR_H
#define __MOTOR_H

#include "stdio.h"	
#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
	  	
extern struct SendData5 __send_data_5;

//��Ƭ������Э��
typedef struct 
{ 	
    uint8_t start;       
    uint8_t model[2];    
    uint8_t command[2];  
    uint8_t param_h[2];  
    uint8_t param_l[2];  
    uint8_t data_h[2];   
    uint8_t data_l[2];   
    uint8_t checksum[2];
    uint8_t CR;
    uint8_t LF;
}SendData5;
#pragma pack()

extern uint8_t Ascii2Hex(const uint8_t data_h, const uint8_t data_l);
extern uint8_t* Hex2Ascii(const uint8_t data);
extern float lagrange(float dis, int n, int flag);
extern uint8_t* pose2data(int position, uint8_t* string);

#endif