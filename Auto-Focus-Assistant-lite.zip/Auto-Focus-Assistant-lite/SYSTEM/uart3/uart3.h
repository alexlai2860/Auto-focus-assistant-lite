#ifndef __UART3_H_
#define __UART3_H_

#include "stm32f10x.h"
#include "stdio.h"	
#include "sys.h" 


extern int manual_pos;
extern int manual_dis;
extern uint8_t manual_data[17];
void uart3_init(u32 bound);
void uart3_send_buff(u8* buf,u32 len);
void uart3_send_char(u8 temp);
void USART_SendString(USART_TypeDef* USARTx, uint8_t *DataString);


#endif

